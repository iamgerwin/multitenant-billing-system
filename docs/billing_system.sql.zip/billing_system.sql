/*
 Navicat Premium Dump SQL

 Source Server         : billing_system
 Source Server Type    : MySQL
 Source Server Version : 80044 (8.0.44)
 Source Host           : localhost:3366
 Source Schema         : billing_system

 Target Server Type    : MySQL
 Target Server Version : 80044 (8.0.44)
 File Encoding         : 65001

 Date: 04/12/2025 15:52:02
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for cache
-- ----------------------------
DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of cache
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for cache_locks
-- ----------------------------
DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of cache_locks
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for failed_jobs
-- ----------------------------
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of failed_jobs
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for invoices
-- ----------------------------
DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint unsigned NOT NULL,
  `vendor_id` bigint unsigned NOT NULL,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `subtotal` decimal(15,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `discount_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `description` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `paid_date` date DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `approved_by` bigint unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_organization_id_invoice_number_unique` (`organization_id`,`invoice_number`),
  KEY `invoices_created_by_foreign` (`created_by`),
  KEY `invoices_approved_by_foreign` (`approved_by`),
  KEY `invoices_organization_id_index` (`organization_id`),
  KEY `invoices_vendor_id_index` (`vendor_id`),
  KEY `invoices_status_index` (`status`),
  KEY `invoices_invoice_date_index` (`invoice_date`),
  CONSTRAINT `invoices_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoices_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of invoices
-- ----------------------------
BEGIN;
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (1, 1, 3, 'INV-2025-0001', '2025-11-28', '2026-01-07', 'pending', 1399.66, 139.97, 0.00, 1539.63, 'USD', 'Monthly service invoice', NULL, NULL, NULL, NULL, 2, NULL, NULL, '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (2, 1, 4, 'INV-2025-0002', '2025-12-02', '2026-01-02', 'pending', 3764.72, 376.47, 0.00, 4141.19, 'USD', 'Monthly service invoice', NULL, NULL, NULL, NULL, 2, NULL, NULL, '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (3, 1, 3, 'INV-2025-0003', '2025-11-21', '2025-12-22', 'approved', 4007.19, 400.72, 200.36, 4207.55, 'USD', 'Quarterly services', NULL, NULL, NULL, NULL, 2, 1, '2025-12-02 18:26:04', '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (4, 1, 4, 'INV-2025-0004', '2025-11-15', '2025-12-17', 'approved', 6672.06, 667.21, 333.60, 7005.67, 'USD', 'Quarterly services', NULL, NULL, NULL, NULL, 2, 1, '2025-11-28 18:26:04', '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (5, 1, 3, 'INV-2025-0005', '2025-11-02', '2025-11-25', 'paid', 14323.82, 1432.38, 0.00, 15756.20, 'USD', 'Annual subscription', NULL, '2025-11-25', 'credit_card', 'PAY-81B0AD24', 2, 1, '2025-10-30 18:26:04', '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (6, 1, 4, 'INV-2025-0006', '2025-10-31', '2025-11-26', 'paid', 7204.95, 720.50, 0.00, 7925.45, 'USD', 'Annual subscription', NULL, '2025-11-29', 'credit_card', 'PAY-10E57718', 2, 1, '2025-10-25 18:26:04', '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (7, 1, 2, 'INV-2025-0007', '2025-10-26', '2025-11-25', 'paid', 9530.28, 953.03, 0.00, 10483.31, 'USD', 'Annual subscription', NULL, '2025-11-29', 'bank_transfer', 'PAY-B2581010', 2, 1, '2025-11-13 18:26:04', '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (8, 1, 3, 'INV-2025-0008', '2025-11-17', '2025-12-08', 'rejected', 999.99, 100.00, 0.00, 1099.99, 'USD', 'Rejected - incorrect amount', 'Invoice amount does not match purchase order. Please resubmit.', NULL, NULL, NULL, 2, NULL, NULL, '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (9, 1, 4, 'INV-2025-0009', '2025-10-19', '2025-11-18', 'pending', 3500.00, 350.00, 0.00, 3850.00, 'USD', 'Overdue invoice - needs attention', 'This invoice requires immediate review.', NULL, NULL, NULL, 2, NULL, NULL, '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (10, 2, 6, 'ACM-20251203-40yvk4ws', '2025-12-03', '2025-12-30', 'pending', 0.00, 10.00, 0.00, 10.00, 'USD', 'te', 'te', NULL, NULL, NULL, 4, NULL, NULL, '2025-12-03 19:22:42', '2025-12-03 19:22:42', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (11, 1, 3, 'INV-067223', '2025-11-15', '2025-12-17', 'rejected', 171.42, 17.14, 7.74, 180.82, 'USD', 'Porro ut cupiditate illum laudantium praesentium optio non.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (12, 1, 2, 'INV-430022', '2025-11-15', '2025-12-23', 'approved', 4483.82, 448.38, 184.44, 4747.76, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (13, 1, 2, 'INV-192173', '2025-11-05', '2025-12-17', 'paid', 5234.33, 523.43, 260.51, 5497.25, 'USD', 'Nesciunt deserunt voluptatem nam non possimus.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (14, 1, 3, 'INV-518535', '2025-11-26', '2025-12-19', 'approved', 1033.35, 103.34, 53.29, 1083.40, 'USD', 'Et natus molestiae facere.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (15, 1, 4, 'INV-546951', '2025-12-03', '2025-12-10', 'paid', 5019.33, 501.93, 473.49, 5047.77, 'USD', 'Harum aut reprehenderit sequi aut quos.', 'Molestias cum recusandae recusandae. Ratione et dignissimos voluptatem dolorem illo saepe. Qui maiores consequatur omnis sunt. Incidunt ab accusamus in quisquam non.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (16, 1, 2, 'INV-468473', '2025-11-06', '2026-01-29', 'rejected', 4079.74, 407.97, 91.67, 4396.04, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (17, 1, 2, 'INV-623527', '2025-11-14', '2025-12-27', 'pending', 8009.07, 800.91, 139.46, 8670.52, 'USD', NULL, 'Accusantium eaque ut hic adipisci dolor. Velit tempora molestias suscipit sed. Distinctio cumque qui ipsum et ut voluptatum consequatur.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (18, 1, 2, 'INV-762497', '2025-11-07', '2025-12-21', 'paid', 6783.24, 678.32, 476.38, 6985.18, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (19, 1, 1, 'INV-263574', '2025-11-16', '2025-12-11', 'rejected', 9680.97, 968.10, 687.49, 9961.58, 'USD', NULL, 'Laudantium aperiam dolor quos similique in corrupti eius. Eaque voluptatem eos consectetur eveniet. Vel quia similique quia maiores sit nostrum.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (20, 1, 3, 'INV-892225', '2025-11-04', '2026-01-19', 'rejected', 772.06, 77.21, 43.35, 805.92, 'USD', 'Illo dolorem quia qui dolore nisi voluptas.', 'Molestiae placeat et saepe doloribus sint dolor maxime. Mollitia alias ipsa incidunt inventore molestias error. Exercitationem in alias sed similique repudiandae veritatis est.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (21, 1, 2, 'INV-861688', '2025-11-23', '2025-12-24', 'pending', 9477.15, 947.72, 503.73, 9921.14, 'USD', 'Culpa hic aut quos doloribus voluptate in est quo.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (22, 1, 1, 'INV-234666', '2025-11-15', '2026-01-12', 'approved', 5882.14, 588.21, 466.35, 6004.00, 'USD', 'Quam in alias voluptatem rerum non eligendi aliquam.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (23, 1, 3, 'INV-827859', '2025-11-24', '2025-12-24', 'pending', 4708.29, 470.83, 120.31, 5058.81, 'USD', 'Debitis aliquam et rerum voluptas et pariatur rerum ullam.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (24, 1, 3, 'INV-426610', '2025-11-12', '2026-01-15', 'approved', 4737.48, 473.75, 15.68, 5195.55, 'USD', 'Molestiae velit in et eos voluptas.', 'Earum et et dolores excepturi dolores vitae in perferendis. Ea aut voluptatibus natus exercitationem possimus. Sit est quisquam voluptas. Et voluptatibus molestiae ea minima architecto vero praesentium dolores.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (25, 1, 2, 'INV-795864', '2025-11-19', '2025-12-06', 'approved', 3814.40, 381.44, 95.51, 4100.33, 'USD', NULL, 'Voluptates omnis officiis porro nihil ut molestiae. Dolores nihil qui ipsum quos velit mollitia. Maxime inventore placeat eligendi occaecati sint ipsa. Quas autem ut explicabo et.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:49', '2025-12-04 07:39:49', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (26, 1, 2, 'INV-257209', '2025-11-12', '2025-12-24', 'paid', 4622.92, 462.29, 82.66, 5002.55, 'USD', NULL, 'Quos adipisci provident molestiae ipsum est expedita. Laboriosam laborum repellat rerum molestias id. Consectetur magni veniam est. Rerum dolor numquam laboriosam.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (27, 1, 2, 'INV-856437', '2025-11-21', '2025-12-27', 'rejected', 8582.80, 858.28, 104.45, 9336.63, 'USD', 'Rerum blanditiis omnis expedita pariatur.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (28, 1, 4, 'INV-231406', '2025-11-13', '2025-12-12', 'paid', 4658.52, 465.85, 34.22, 5090.15, 'USD', NULL, 'Tempora occaecati eum vel enim asperiores. Distinctio omnis in quae aut. Magni labore necessitatibus consequatur facilis vel repellendus blanditiis.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (29, 1, 3, 'INV-480684', '2025-12-02', '2025-12-19', 'rejected', 3916.65, 391.67, 255.78, 4052.54, 'USD', 'Pariatur sint sunt sit corrupti aut quae et.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (30, 1, 3, 'INV-840389', '2025-11-08', '2025-12-25', 'approved', 6491.94, 649.19, 6.95, 7134.18, 'USD', 'Perferendis aperiam et quibusdam voluptatem consequuntur quisquam.', 'Facere autem consequuntur atque et enim delectus laboriosam. Sit aliquid velit laudantium voluptatum aut. Quia voluptatem magni consequuntur officiis doloribus sunt. Soluta voluptatem vero iusto repellat dicta recusandae.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (31, 1, 4, 'INV-409700', '2025-11-15', '2026-01-18', 'approved', 6885.51, 688.55, 511.15, 7062.91, 'USD', 'Nam odio quaerat sed sequi deleniti quia possimus.', 'Cupiditate quia dolores quia in. Sequi ea vel numquam velit earum exercitationem. Inventore est qui nobis.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (32, 1, 1, 'INV-988851', '2025-11-23', '2026-01-04', 'paid', 6221.41, 622.14, 127.94, 6715.61, 'USD', 'Quas similique dolor omnis cum.', 'Quidem voluptate sunt magnam reprehenderit et. Exercitationem beatae nemo qui est neque aspernatur esse. Repellat sunt qui rem.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (33, 1, 3, 'INV-563240', '2025-11-12', '2025-12-15', 'rejected', 6636.23, 663.62, 620.47, 6679.38, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (34, 1, 1, 'INV-481910', '2025-11-18', '2025-12-11', 'paid', 1128.26, 112.83, 26.17, 1214.92, 'USD', 'Atque fugiat sit similique aut omnis.', 'Rerum vel incidunt cumque esse magnam. Magnam cum quis aut eos fugit perferendis illo beatae. Nisi fugit sed delectus possimus iste sunt nostrum.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (35, 1, 1, 'INV-362927', '2025-11-07', '2026-01-10', 'approved', 551.36, 55.14, 37.21, 569.29, 'USD', NULL, 'Omnis ut et voluptatem quia et vitae. Et omnis rerum qui nihil reiciendis veniam. Odit deserunt aut ex beatae sint quas. Maxime dicta rerum quasi dolores saepe eligendi illo.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (36, 1, 2, 'INV-799936', '2025-11-14', '2025-12-07', 'approved', 1658.73, 165.87, 72.56, 1752.04, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (37, 1, 3, 'INV-817709', '2025-11-09', '2025-12-24', 'pending', 8560.94, 856.09, 158.73, 9258.30, 'USD', 'Suscipit ut et aut perspiciatis vel.', 'Qui est et repudiandae provident consequatur. Voluptas quia cupiditate aperiam. Quasi odio sed nobis deleniti quasi ut.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (38, 1, 4, 'INV-591629', '2025-11-27', '2026-01-10', 'rejected', 5831.86, 583.19, 414.55, 6000.50, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (39, 1, 1, 'INV-798647', '2025-11-18', '2025-12-24', 'pending', 8870.27, 887.03, 691.00, 9066.30, 'USD', 'Quaerat consequatur itaque illo et.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (40, 1, 3, 'INV-255716', '2025-12-02', '2026-01-21', 'rejected', 8227.91, 822.79, 325.99, 8724.71, 'USD', NULL, 'Consectetur nemo dolore perspiciatis reprehenderit provident quo voluptatum. Repellat numquam corrupti blanditiis reprehenderit sed quis. Consequatur esse excepturi pariatur.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (41, 1, 4, 'INV-783948', '2025-11-19', '2026-01-30', 'pending', 1337.86, 133.79, 7.73, 1463.92, 'USD', 'Voluptatem eum excepturi vero consequatur consequatur asperiores a.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (42, 1, 4, 'INV-221975', '2025-12-01', '2025-12-27', 'pending', 136.52, 13.65, 10.59, 139.58, 'USD', 'Incidunt voluptate et expedita ut in molestiae fugit.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (43, 1, 4, 'INV-390596', '2025-11-14', '2025-12-18', 'paid', 2896.49, 289.65, 231.87, 2954.27, 'USD', 'Laudantium est soluta cupiditate laboriosam nesciunt tenetur.', 'Quasi omnis iste debitis in eius voluptates. Nobis est ut nulla vitae nihil alias quas. Molestiae dolore necessitatibus nemo dicta aut quia. Debitis vitae tempore quae mollitia.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (44, 1, 2, 'INV-801808', '2025-12-02', '2025-12-04', 'pending', 3332.95, 333.30, 181.58, 3484.67, 'USD', NULL, 'Optio velit fugit eum delectus neque. Qui nulla tempora tenetur dolorem. Quia ut et sunt.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (45, 1, 1, 'INV-407270', '2025-11-30', '2025-12-23', 'approved', 4937.53, 493.75, 323.84, 5107.44, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (46, 1, 2, 'INV-185518', '2025-11-25', '2026-01-01', 'pending', 6986.31, 698.63, 36.48, 7648.46, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (47, 1, 3, 'INV-862228', '2025-11-15', '2025-12-12', 'pending', 8638.65, 863.87, 850.33, 8652.19, 'USD', 'Et omnis ipsa pariatur qui quia.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (48, 1, 4, 'INV-288797', '2025-11-29', '2025-12-23', 'approved', 6054.49, 605.45, 207.14, 6452.80, 'USD', NULL, 'Velit vitae quidem ut quibusdam corrupti error ea dolorum. Eaque sit nihil aut voluptatem nihil libero. Minus dolores et tenetur vero eaque laudantium nisi.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (49, 1, 2, 'INV-192818', '2025-11-29', '2026-01-06', 'paid', 1309.09, 130.91, 85.74, 1354.26, 'USD', 'Corporis sit vel cupiditate voluptatem officiis praesentium temporibus sunt.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (50, 1, 3, 'INV-221634', '2025-11-23', '2025-12-10', 'paid', 4627.82, 462.78, 56.61, 5033.99, 'USD', 'Vitae omnis quas vel.', 'Ut voluptates minus id cum. Quae fugit quas vel autem et labore voluptatem id. Culpa voluptatem rem tenetur nostrum id. Quaerat quis cum eum in.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (51, 1, 3, 'INV-706986', '2025-11-17', '2026-01-13', 'paid', 8445.98, 844.60, 627.43, 8663.15, 'USD', 'Aut ipsam minus debitis at ut nesciunt qui.', 'Nobis et sed fuga distinctio recusandae sapiente nemo. Labore at quia ut pariatur quo quia deleniti libero. Repellendus nemo atque adipisci totam id odit eos. Qui non quia est quibusdam.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (52, 1, 2, 'INV-608917', '2025-11-17', '2026-01-15', 'paid', 2538.65, 253.87, 136.20, 2656.32, 'USD', 'Aperiam et ab qui rerum enim.', 'Enim exercitationem maiores ut quasi. Assumenda qui et in occaecati. Perspiciatis ea necessitatibus et ad reiciendis. Pariatur voluptates dolores quibusdam aut pariatur.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (53, 1, 4, 'INV-760884', '2025-11-28', '2026-01-31', 'paid', 9965.93, 996.59, 227.98, 10734.54, 'USD', NULL, 'Quia vel aut et unde sunt voluptatem. Eaque ipsum eos amet mollitia illum.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (54, 1, 1, 'INV-292597', '2025-12-03', '2026-01-18', 'pending', 2927.88, 292.79, 234.74, 2985.93, 'USD', NULL, 'Et adipisci quaerat tempora libero ex. Ipsum temporibus tenetur necessitatibus ullam.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (55, 1, 2, 'INV-011094', '2025-11-12', '2026-01-12', 'paid', 7819.53, 781.95, 361.85, 8239.63, 'USD', 'Eos cum et ut beatae blanditiis iusto.', 'Ea dolores facere autem. A quo harum voluptates.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (56, 1, 4, 'INV-067725', '2025-11-14', '2026-01-17', 'rejected', 525.65, 52.57, 2.16, 576.06, 'USD', 'Dolore id aut molestiae dicta quis iusto voluptas.', 'Error placeat quidem mollitia et qui molestias aut. Qui tenetur sed quisquam. Quas et quas ducimus iste corrupti eius. Neque rerum non exercitationem consequuntur temporibus.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (57, 1, 2, 'INV-179606', '2025-12-02', '2025-12-16', 'rejected', 1079.75, 107.98, 33.42, 1154.31, 'USD', NULL, 'Culpa nihil et similique consequuntur voluptatem qui adipisci voluptatem. Sit aliquid odio ut iusto. Ipsa culpa blanditiis excepturi natus aut. Nam non facilis commodi distinctio soluta tenetur. Maiores mollitia sed ea et qui dolor.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (58, 1, 2, 'INV-374515', '2025-12-02', '2026-01-15', 'rejected', 6492.40, 649.24, 93.25, 7048.39, 'USD', 'Similique sint dolorem id voluptatem ea perferendis.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (59, 1, 4, 'INV-471119', '2025-11-15', '2026-01-24', 'pending', 4805.58, 480.56, 278.06, 5008.08, 'USD', 'Enim vero non iusto eius.', 'Ut vitae consectetur esse eaque voluptatem dolorem soluta. Officiis sunt harum in dolorem natus totam in saepe. Et dolore alias et expedita ut voluptatibus. Modi saepe rerum numquam magni neque quidem.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (60, 1, 2, 'INV-812334', '2025-11-15', '2026-01-20', 'rejected', 1392.84, 139.28, 138.66, 1393.46, 'USD', 'Adipisci autem sunt veritatis deleniti excepturi.', 'Cupiditate beatae a exercitationem eaque et cumque. Eum nulla esse sint.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (61, 1, 2, 'INV-408360', '2025-11-14', '2026-01-29', 'rejected', 8693.71, 869.37, 127.44, 9435.64, 'USD', NULL, 'Recusandae temporibus quia quis architecto eum iusto. Ipsum nihil aut et sed sit repudiandae. Ut non et enim sit.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (62, 1, 1, 'INV-035378', '2025-11-08', '2026-01-15', 'pending', 7188.09, 718.81, 530.83, 7376.07, 'USD', 'Perspiciatis minus quidem dolorum harum voluptatum pariatur.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (63, 1, 2, 'INV-318542', '2025-11-26', '2025-12-11', 'rejected', 4898.48, 489.85, 357.75, 5030.58, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (64, 1, 1, 'INV-315643', '2025-11-17', '2025-12-18', 'pending', 1652.21, 165.22, 115.82, 1701.61, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (65, 1, 3, 'INV-526732', '2025-11-04', '2025-12-07', 'paid', 5740.16, 574.02, 217.52, 6096.66, 'USD', 'Quae aut ut et repellendus qui ipsa et.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (66, 1, 2, 'INV-285377', '2025-11-14', '2026-02-01', 'approved', 6691.80, 669.18, 551.79, 6809.19, 'USD', NULL, 'Odio eos eum temporibus alias qui molestiae. Quo eius iusto optio voluptas praesentium. Quis nemo nemo ducimus atque.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (67, 1, 1, 'INV-807456', '2025-11-25', '2025-12-21', 'paid', 790.82, 79.08, 77.26, 792.64, 'USD', NULL, 'Eaque sit omnis eaque nihil commodi sunt est. Quaerat explicabo est consequatur suscipit laudantium iusto est. Tempore cumque assumenda quia magni minus.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (68, 1, 4, 'INV-570771', '2025-11-18', '2026-01-09', 'pending', 6110.95, 611.10, 570.31, 6151.74, 'USD', 'Est consequatur tempora non tempore.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (69, 1, 2, 'INV-800006', '2025-12-01', '2025-12-16', 'rejected', 2889.34, 288.93, 245.18, 2933.09, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (70, 1, 1, 'INV-109685', '2025-11-22', '2026-01-15', 'approved', 748.92, 74.89, 34.06, 789.75, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (71, 1, 3, 'INV-811251', '2025-11-13', '2026-02-01', 'approved', 4521.02, 452.10, 410.46, 4562.66, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (72, 1, 3, 'INV-348275', '2025-11-17', '2026-01-22', 'approved', 1308.04, 130.80, 37.43, 1401.41, 'USD', 'Vel quisquam quia voluptatibus doloremque consequatur qui quo.', 'Sint nobis dolor quasi perspiciatis tenetur. Nisi amet excepturi a molestias veniam quis. At eius quasi eum sed. Voluptas totam pariatur possimus cum labore iusto.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (73, 1, 4, 'INV-026021', '2025-11-13', '2026-01-08', 'approved', 8020.04, 802.00, 223.83, 8598.21, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (74, 1, 1, 'INV-979649', '2025-11-05', '2025-12-19', 'paid', 8282.24, 828.22, 649.95, 8460.51, 'USD', 'Dolorem saepe reiciendis odit tempore aliquam facere sed et.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (75, 1, 1, 'INV-907168', '2025-11-07', '2026-01-18', 'approved', 6000.18, 600.02, 237.00, 6363.20, 'USD', NULL, 'Qui est consectetur quasi et minima ducimus. Qui dolorum laborum ut voluptas ut. Itaque vitae explicabo recusandae ut quos. Non quis dignissimos et accusantium ipsa iure eum.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (76, 1, 2, 'INV-513206', '2025-11-07', '2026-01-02', 'approved', 2007.75, 200.78, 99.41, 2109.12, 'USD', 'Quia quam asperiores mollitia.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (77, 1, 4, 'INV-587881', '2025-11-16', '2026-01-15', 'paid', 6452.47, 645.25, 633.27, 6464.45, 'USD', NULL, 'Molestias similique dolorum laborum quas expedita minima perspiciatis ullam. Omnis quod eum et praesentium veniam. Fuga nisi nisi nostrum veniam enim sit. Quo rerum debitis autem consectetur soluta.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (78, 1, 3, 'INV-337500', '2025-11-14', '2026-01-21', 'rejected', 9942.85, 994.29, 81.58, 10855.56, 'USD', 'Molestiae excepturi aut aut.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (79, 1, 4, 'INV-117545', '2025-11-24', '2026-01-11', 'rejected', 2171.76, 217.18, 180.43, 2208.51, 'USD', NULL, 'Voluptas nesciunt deleniti sint molestiae est. Ducimus et aliquam necessitatibus mollitia velit. Ut distinctio aut qui quasi aliquam asperiores. Quia officiis qui non nihil consequatur numquam. Natus maiores atque est dolore aperiam.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (80, 1, 4, 'INV-318892', '2025-11-08', '2026-01-15', 'paid', 6871.32, 687.13, 87.69, 7470.76, 'USD', 'Nam illum sit ab voluptas aut.', 'Eius voluptates id pariatur voluptatum recusandae nulla ipsam aut. Velit natus delectus cum et. Et ut repellendus aliquam mollitia et vel maxime.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (81, 1, 2, 'INV-088774', '2025-11-13', '2025-12-08', 'pending', 6272.98, 627.30, 287.60, 6612.68, 'USD', 'Illo ut explicabo vel dicta ab est veritatis.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (82, 1, 3, 'INV-007494', '2025-11-27', '2025-12-07', 'rejected', 9485.62, 948.56, 339.22, 10094.96, 'USD', 'Ipsum nam nisi qui rerum.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (83, 1, 3, 'INV-439005', '2025-12-01', '2025-12-06', 'pending', 6240.34, 624.03, 477.07, 6387.30, 'USD', NULL, 'Accusantium excepturi aliquam odit et et enim. Magni voluptatum vitae praesentium rem provident voluptas.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (84, 1, 3, 'INV-919255', '2025-12-01', '2025-12-17', 'rejected', 3392.21, 339.22, 96.81, 3634.62, 'USD', 'Possimus necessitatibus non consequatur pariatur.', 'Nesciunt maiores rerum perferendis omnis rerum harum. Aut velit esse et voluptates. Earum illo et nostrum et dolorem est magnam. Consequatur voluptatum rerum laborum sed aut.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (85, 1, 4, 'INV-313444', '2025-11-06', '2026-01-05', 'pending', 2602.83, 260.28, 168.50, 2694.61, 'USD', 'Consequatur consequatur officiis omnis corrupti.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (86, 1, 4, 'INV-045741', '2025-11-07', '2026-01-15', 'approved', 2294.92, 229.49, 4.50, 2519.91, 'USD', 'Quidem officia consequuntur odio aliquid.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (87, 1, 1, 'INV-920478', '2025-12-04', '2026-01-21', 'paid', 4510.18, 451.02, 223.60, 4737.60, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (88, 1, 2, 'INV-264995', '2025-11-07', '2026-01-14', 'paid', 2185.16, 218.52, 151.93, 2251.75, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (89, 1, 2, 'INV-274904', '2025-11-28', '2026-01-27', 'pending', 3280.54, 328.05, 24.11, 3584.48, 'USD', 'Laboriosam aliquid dolor quos temporibus.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (90, 1, 3, 'INV-945971', '2025-11-12', '2026-01-27', 'pending', 8703.78, 870.38, 477.53, 9096.63, 'USD', NULL, 'Et eligendi laboriosam quo quia ut recusandae magnam. Quo ratione blanditiis libero velit ipsam doloremque. Quaerat voluptate mollitia et vero modi. Dignissimos eos nesciunt iusto veritatis.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (91, 1, 2, 'INV-237674', '2025-11-19', '2026-01-08', 'paid', 982.84, 98.28, 88.72, 992.40, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (92, 1, 3, 'INV-479989', '2025-11-11', '2025-12-15', 'paid', 5072.15, 507.22, 15.31, 5564.06, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (93, 1, 2, 'INV-501376', '2025-11-13', '2025-12-29', 'pending', 5903.18, 590.32, 133.29, 6360.21, 'USD', 'Esse iste deleniti nam nam qui.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (94, 1, 3, 'INV-605299', '2025-11-07', '2026-01-28', 'pending', 1520.55, 152.06, 143.82, 1528.79, 'USD', 'Occaecati asperiores in magnam aperiam illum molestias laboriosam.', 'Labore iusto placeat provident consequuntur sequi adipisci numquam voluptatem. Repellat sit ea at.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (95, 1, 1, 'INV-919275', '2025-11-23', '2026-01-25', 'approved', 9214.26, 921.43, 803.20, 9332.49, 'USD', 'Hic quae ex nam occaecati.', 'Veritatis at omnis repudiandae in ab. Aut ab et voluptatibus consequatur aut. A sunt delectus placeat sed.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (96, 1, 4, 'INV-592556', '2025-11-04', '2026-01-23', 'rejected', 1751.86, 175.19, 146.92, 1780.13, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (97, 1, 2, 'INV-050339', '2025-11-18', '2025-12-22', 'paid', 8933.57, 893.36, 696.80, 9130.13, 'USD', NULL, 'Pariatur ipsa ipsam soluta nisi ut a rerum. Et eveniet a voluptatem quis velit. Dicta quis aut consectetur beatae aspernatur numquam asperiores. Quod quidem ut cupiditate.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (98, 1, 3, 'INV-628769', '2025-11-23', '2026-01-01', 'pending', 4512.95, 451.30, 357.79, 4606.46, 'USD', 'Ea iure ut eaque nostrum sed maiores.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (99, 1, 3, 'INV-477577', '2025-11-19', '2025-12-24', 'paid', 8594.07, 859.41, 252.28, 9201.20, 'USD', NULL, 'Quibusdam dolores libero sunt. Rerum voluptatem sunt dolor vero sint repellendus. Dolor repudiandae illum blanditiis voluptatem dolore et. Maiores laboriosam qui tempora consequatur optio.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (100, 1, 2, 'INV-993554', '2025-12-02', '2026-01-31', 'paid', 4764.68, 476.47, 155.45, 5085.70, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (101, 1, 1, 'INV-232166', '2025-11-18', '2026-01-11', 'pending', 4669.23, 466.92, 289.24, 4846.91, 'USD', 'Dolor aut aliquid neque temporibus.', 'Aspernatur beatae voluptatem placeat id. Omnis ut neque odio praesentium rerum repellendus ut. Harum alias ut assumenda est omnis exercitationem. Quae qui est minus mollitia. Corporis explicabo consequatur ipsum id ut nisi esse.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (102, 1, 4, 'INV-133921', '2025-11-29', '2025-12-30', 'paid', 3588.37, 358.84, 262.76, 3684.45, 'USD', 'Repellat consectetur mollitia et architecto ea.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (103, 1, 1, 'INV-031625', '2025-12-03', '2025-12-31', 'approved', 3449.39, 344.94, 270.45, 3523.88, 'USD', NULL, 'Et eum ut dolore architecto. At fugit culpa saepe qui et. Ut expedita molestiae quia ex. Repellat odio autem maiores aspernatur cum nihil.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (104, 1, 4, 'INV-334114', '2025-11-23', '2026-01-16', 'paid', 3765.71, 376.57, 205.67, 3936.61, 'USD', 'Voluptas iure inventore nisi.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (105, 1, 3, 'INV-282150', '2025-11-08', '2025-12-16', 'paid', 9419.25, 941.93, 178.59, 10182.59, 'USD', NULL, 'Suscipit delectus quas non dolores ipsa est vitae. Architecto rerum et explicabo suscipit. Est iure eos quas.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (106, 1, 2, 'INV-923000', '2025-11-08', '2026-01-06', 'rejected', 3276.44, 327.64, 162.13, 3441.95, 'USD', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (107, 1, 3, 'INV-058901', '2025-11-10', '2026-01-25', 'approved', 9639.26, 963.93, 32.87, 10570.32, 'USD', NULL, 'Ullam atque est velit. Et rerum et qui aliquam impedit modi sunt quia. Quis quia nisi aspernatur odit odio alias. Delectus voluptatem tenetur autem cupiditate excepturi.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (108, 1, 2, 'INV-286628', '2025-11-13', '2025-12-07', 'rejected', 5735.22, 573.52, 198.89, 6109.85, 'USD', 'Quam non ut veniam.', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (109, 1, 1, 'INV-913045', '2025-11-09', '2026-02-01', 'rejected', 3510.72, 351.07, 109.80, 3751.99, 'USD', 'Et facere vitae provident odit consequatur eligendi.', 'Quos expedita quasi consequatur odit commodi porro. Quos cum architecto ex ut qui eius. Nobis voluptatem et non molestias et ipsam consequatur.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
INSERT INTO `invoices` (`id`, `organization_id`, `vendor_id`, `invoice_number`, `invoice_date`, `due_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `currency`, `description`, `notes`, `paid_date`, `payment_method`, `payment_reference`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (110, 1, 1, 'INV-812425', '2025-11-10', '2026-01-30', 'paid', 4992.85, 499.29, 70.18, 5421.96, 'USD', NULL, 'Nihil ea rerum est alias cumque. Impedit et quo enim qui rerum culpa qui. Et quae quis unde ullam ut quas non.', NULL, NULL, NULL, 1, NULL, NULL, '2025-12-04 07:39:50', '2025-12-04 07:39:50', NULL);
COMMIT;

-- ----------------------------
-- Table structure for job_batches
-- ----------------------------
DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of job_batches
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for jobs
-- ----------------------------
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of jobs
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of migrations
-- ----------------------------
BEGIN;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1, '0001_01_01_000000_create_users_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (2, '0001_01_01_000001_create_cache_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (3, '0001_01_01_000002_create_jobs_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (4, '2025_12_01_185045_create_organizations_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (5, '2025_12_01_185118_add_organization_id_and_role_to_users_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (6, '2025_12_01_185151_create_vendors_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (7, '2025_12_01_185226_create_invoices_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (8, '2025_12_03_182837_create_personal_access_tokens_table', 2);
COMMIT;

-- ----------------------------
-- Table structure for organizations
-- ----------------------------
DROP TABLE IF EXISTS `organizations`;
CREATE TABLE `organizations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `organizations_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of organizations
-- ----------------------------
BEGIN;
INSERT INTO `organizations` (`id`, `name`, `slug`, `email`, `phone`, `address`, `city`, `state`, `postal_code`, `country`, `tax_id`, `currency`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES (1, 'Demo Company', 'demo-company', 'info@demo-company.com', '+1 (555) 123-4567', '123 Business Street', 'San Francisco', 'CA', '94102', 'United States', 'US-123456789', 'USD', 1, '2025-12-03 18:26:02', '2025-12-03 18:26:02', NULL);
INSERT INTO `organizations` (`id`, `name`, `slug`, `email`, `phone`, `address`, `city`, `state`, `postal_code`, `country`, `tax_id`, `currency`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES (2, 'Acme Corporation', 'acme-corp', 'contact@acme-corp.com', '+1 (555) 987-6543', '456 Enterprise Avenue', 'New York', 'NY', '10001', 'United States', 'US-987654321', 'USD', 1, '2025-12-03 18:26:02', '2025-12-03 18:26:02', NULL);
COMMIT;

-- ----------------------------
-- Table structure for password_reset_tokens
-- ----------------------------
DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of password_reset_tokens
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for personal_access_tokens
-- ----------------------------
DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of personal_access_tokens
-- ----------------------------
BEGIN;
INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES (1, 'App\\Models\\User', 1, 'api-token', '726cc87689941c1c3802371a8bf71e255a5f9dcdc73a386be95a524b967e49ac', '[\"*\"]', NULL, NULL, '2025-12-03 18:28:54', '2025-12-03 18:28:54');
INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES (2, 'App\\Models\\User', 1, 'api-token', '7940fe8343773c79c688e953e7e04a61ade487ab508a53cab568d99aaecf7a3c', '[\"*\"]', NULL, NULL, '2025-12-03 18:41:09', '2025-12-03 18:41:09');
INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES (5, 'App\\Models\\User', 4, 'test', 'b83566ba46ba53f0d666fa4c9c3e414fd9ac991877da01f21ee87e84ab7fa00c', '[\"*\"]', '2025-12-03 19:24:44', NULL, '2025-12-03 19:06:23', '2025-12-03 19:24:44');
INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES (6, 'App\\Models\\User', 1, 'test', '8d54afa84e8856c29611132e147b574dcbae8113e37ec178d9e94c01a1e815b4', '[\"*\"]', '2025-12-03 19:25:08', NULL, '2025-12-03 19:25:01', '2025-12-03 19:25:08');
INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES (16, 'App\\Models\\User', 3, 'api-token', '17e28d0e65a6c6f3b5df224f01a7ff3013e011132505635148efafd0c2be8061', '[\"*\"]', NULL, NULL, '2025-12-04 06:21:08', '2025-12-04 06:21:08');
INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES (21, 'App\\Models\\User', 1, 'api-token', '52cafc65c09579db37def68a9eadeff397629ba0a440bae15969683b1ad4d21a', '[\"*\"]', '2025-12-04 07:28:14', NULL, '2025-12-04 07:14:40', '2025-12-04 07:28:14');
INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES (22, 'App\\Models\\User', 1, 'api-token', '10846a00ab2db12d5bd8c479c883aa956b81029f7ee47aae57cb3ba7c90e7fb6', '[\"*\"]', '2025-12-04 07:26:19', NULL, '2025-12-04 07:18:40', '2025-12-04 07:26:19');
INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES (25, 'App\\Models\\User', 1, 'api-token', '42521adbab7761bb967c1ede85813fdee8d88a90147f8afdcd01db6ea8db16ff', '[\"*\"]', '2025-12-04 07:43:13', NULL, '2025-12-04 07:35:05', '2025-12-04 07:43:13');
COMMIT;

-- ----------------------------
-- Table structure for sessions
-- ----------------------------
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of sessions
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint unsigned DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_organization_id_index` (`organization_id`),
  KEY `users_role_index` (`role`),
  CONSTRAINT `users_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of users
-- ----------------------------
BEGIN;
INSERT INTO `users` (`id`, `organization_id`, `role`, `is_active`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES (1, 1, 'admin', 1, 'Demo Admin', 'admin@demo.com', '2025-12-03 18:26:03', '$2y$12$GZ1dPEEZVghK24kVy0xHY.gTWxbJ/.DPclrudDCFzBtJLqBFPGhsm', NULL, '2025-12-03 18:26:03', '2025-12-03 18:26:03');
INSERT INTO `users` (`id`, `organization_id`, `role`, `is_active`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES (2, 1, 'accountant', 1, 'Demo Accountant', 'accountant@demo.com', '2025-12-03 18:26:03', '$2y$12$7K7YS6xPWF/6zRzoJ2L5M.H4pN6fytTdlrNnYo0xOs2X2n7MwLDkC', NULL, '2025-12-03 18:26:03', '2025-12-03 18:26:03');
INSERT INTO `users` (`id`, `organization_id`, `role`, `is_active`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES (3, 1, 'user', 1, 'Demo User', 'user@demo.com', '2025-12-03 18:26:03', '$2y$12$csxtFGS9g.7B8ngvu4GTlOq4P6CYkCVU4DJZmAO6AT6Yoy21VbIRO', NULL, '2025-12-03 18:26:03', '2025-12-03 18:26:03');
INSERT INTO `users` (`id`, `organization_id`, `role`, `is_active`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES (4, 2, 'admin', 1, 'Acme Admin', 'admin@acme.com', '2025-12-03 18:26:03', '$2y$12$TrkZaZsTR5wJ7qPwpzg/deVWJs0wz4E4KtgxLfoRPovzn/O9Da6oW', NULL, '2025-12-03 18:26:03', '2025-12-03 18:26:03');
INSERT INTO `users` (`id`, `organization_id`, `role`, `is_active`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES (5, 2, 'accountant', 1, 'Acme Accountant', 'accountant@acme.com', '2025-12-03 18:26:04', '$2y$12$pz7WRfedIdQllZag7QXpAO1M2ZJUp6kgFpVzTqZXhiEiibdezh5Cu', NULL, '2025-12-03 18:26:04', '2025-12-03 18:26:04');
COMMIT;

-- ----------------------------
-- Table structure for vendors
-- ----------------------------
DROP TABLE IF EXISTS `vendors`;
CREATE TABLE `vendors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_terms` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendors_organization_id_code_unique` (`organization_id`,`code`),
  KEY `vendors_organization_id_index` (`organization_id`),
  CONSTRAINT `vendors_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of vendors
-- ----------------------------
BEGIN;
INSERT INTO `vendors` (`id`, `organization_id`, `name`, `code`, `email`, `phone`, `address`, `city`, `state`, `postal_code`, `country`, `tax_id`, `payment_terms`, `notes`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES (1, 1, 'Tech Supplies Inc.', 'TECH-001', 'billing@techsupplies.com', '+1 (555) 111-2222', '100 Tech Park Drive', 'San Jose', 'CA', '95110', 'United States', 'US-111222333', '30', 'Primary technology vendor for hardware and software.', 1, '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `vendors` (`id`, `organization_id`, `name`, `code`, `email`, `phone`, `address`, `city`, `state`, `postal_code`, `country`, `tax_id`, `payment_terms`, `notes`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES (2, 1, 'Office Solutions LLC', 'OFF-002', 'accounts@officesolutions.com', '+1 (555) 333-4444', '200 Commerce Blvd', 'Oakland', 'CA', '94612', 'United States', 'US-444555666', '15', 'Office furniture and supplies vendor.', 1, '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `vendors` (`id`, `organization_id`, `name`, `code`, `email`, `phone`, `address`, `city`, `state`, `postal_code`, `country`, `tax_id`, `payment_terms`, `notes`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES (3, 1, 'Cloud Services Pro', 'CLD-003', 'invoices@cloudservicespro.com', '+1 (555) 555-6666', '300 Data Center Way', 'Seattle', 'WA', '98101', 'United States', 'US-777888999', '45', 'Cloud hosting and infrastructure services.', 1, '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `vendors` (`id`, `organization_id`, `name`, `code`, `email`, `phone`, `address`, `city`, `state`, `postal_code`, `country`, `tax_id`, `payment_terms`, `notes`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES (4, 1, 'Marketing Agency Plus', 'MKT-004', 'finance@marketingplus.com', '+1 (555) 777-8888', '400 Creative Lane', 'Los Angeles', 'CA', '90001', 'United States', 'US-101112131', '30', 'Digital marketing and advertising services.', 1, '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `vendors` (`id`, `organization_id`, `name`, `code`, `email`, `phone`, `address`, `city`, `state`, `postal_code`, `country`, `tax_id`, `payment_terms`, `notes`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES (5, 1, 'Legacy Systems Corp', 'LEG-005', 'ar@legacysystems.com', '+1 (555) 999-0000', '500 Old Tech Road', 'Phoenix', 'AZ', '85001', 'United States', 'US-141516171', '60', 'Legacy system maintenance - inactive vendor.', 0, '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `vendors` (`id`, `organization_id`, `name`, `code`, `email`, `phone`, `address`, `city`, `state`, `postal_code`, `country`, `tax_id`, `payment_terms`, `notes`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES (6, 2, 'Industrial Parts Co.', 'IND-001', 'sales@industrialparts.com', '+1 (555) 222-3333', '600 Factory Row', 'Detroit', 'MI', '48201', 'United States', 'US-181920212', '30', 'Manufacturing parts and components.', 1, '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
INSERT INTO `vendors` (`id`, `organization_id`, `name`, `code`, `email`, `phone`, `address`, `city`, `state`, `postal_code`, `country`, `tax_id`, `payment_terms`, `notes`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES (7, 2, 'Logistics Express', 'LOG-002', 'billing@logisticsexpress.com', '+1 (555) 444-5555', '700 Shipping Center', 'Chicago', 'IL', '60601', 'United States', 'US-222324252', '15', 'Shipping and logistics services.', 1, '2025-12-03 18:26:04', '2025-12-03 18:26:04', NULL);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
